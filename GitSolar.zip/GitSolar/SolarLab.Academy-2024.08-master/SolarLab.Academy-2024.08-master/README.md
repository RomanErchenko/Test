# SolarLab.Academy-2024.08
Demo-проект для Академия SolarLab 2024 Backend

Техническое задание:
[Техническое задание.pdf](https://github.com/user-attachments/files/16677226/default.pdf)
