﻿using Xunit;

namespace SolarLab.Academy.Tests
{
    public class Tests
    {
        [Fact]
        public void Test1()
        {
            Assert.Equal(2 + 2, 4);

            //TODO
        }
    }
}
